import React, { useState, useEffect, useRef } from 'react';
import { useLocation } from 'react-router-dom';
import { Search, Filter, Calendar, Users, MapPin, ChevronDown } from 'lucide-react';
import EventCard from '../components/EventCard';
import type { Event } from '../types';
import { api, PaginationResponse } from '../api';
import Modal from '../components/Modal';
import ChatbotWidget from '../components/ChatbotWidget';
import { useAuth } from '../contexts/AuthContext';
import hpBG from './hp.jpg';

// HomePage component displays the main event listing, search, and registration UI
const HomePage: React.FC = () => {
  const { user, isAuthenticated } = useAuth();
  const [events, setEvents] = useState<Event[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [showRegisterModal, setShowRegisterModal] = useState(false);
  const [selectedEvent, setSelectedEvent] = useState<Event | null>(null);
  const [hasMore, setHasMore] = useState(false);
  const [nextOffset, setNextOffset] = useState<number | null>(null);
  const [registrationForm, setRegistrationForm] = useState({
    name: '',
    email: '',
    phone: ''
  });
  const [isRegistering, setIsRegistering] = useState(false);
  const [registrationMessage, setRegistrationMessage] = useState<{
    type: 'success' | 'error';
    text: string;
  } | null>(null);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [registrationData, setRegistrationData] = useState<{
    name: string;
    email: string;
    phone: string;
    eventTitle: string;
  } | null>(null);
  const [isClient, setIsClient] = useState(false);
  const [animationsReady, setAnimationsReady] = useState(false);
  const [pendingSearchTerm, setPendingSearchTerm] = useState('');
  const [activeSearchTerm, setActiveSearchTerm] = useState('');
  const [featuredEvent, setFeaturedEvent] = useState<Event | null>(null);
  const [categories, setCategories] = useState<string[]>(['All']);

  // Animation refs
  const heroRef = useRef<HTMLDivElement>(null);
  const eventsRef = useRef<HTMLDivElement>(null);
  const isInitialLoad = useRef(true);
  const location = useLocation();
  const [shouldScrollToEvents, setShouldScrollToEvents] = useState(false);

  // Responsive pagination sizes - Safe window access
  const getInitialLimit = () => {
    if (typeof window === 'undefined') return 6; // Default for SSR
    return 6; // Always show 6 events initially
  };

  const getLoadMoreLimit = () => {
    return 3; // Always load 3 more
  };

  useEffect(() => {
    // Set client-side flag to prevent hydration mismatches
    setIsClient(true);
    loadInitialEvents();
    loadCategories();
  }, []);

  useEffect(() => {
    // Setup animations only after content is loaded and client is ready
    if (isClient && !loading && !animationsReady) {
      const timer = setTimeout(() => {
        setAnimationsReady(true);
        triggerScrollAnimations();
      }, 100); // Small delay to ensure DOM is ready

      return () => clearTimeout(timer);
    }
  }, [isClient, loading, animationsReady]);

  useEffect(() => {
    if (events.length > 0) {
      if (!featuredEvent) {
        setFeaturedEvent(events[0]);
      }
    } else {
      // Clear featured event when no results
      setFeaturedEvent(null);
    }
    // Only scroll if a search/filter was performed
    if (shouldScrollToEvents) {
      eventsRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      setShouldScrollToEvents(false);
    }
  }, [events, featuredEvent, shouldScrollToEvents]);

  useEffect(() => {
    // Reload events when search or category changes
    if (isClient) {
      setAnimationsReady(false); // Reset animations for new content
      loadInitialEvents();
      // Only scroll if not initial load and on home page
      if (!isInitialLoad.current && location.pathname === '/') {
        setShouldScrollToEvents(true);
      }
    }
  }, [activeSearchTerm, selectedCategory, isClient, location.pathname]);

  const triggerScrollAnimations = () => {
    if (typeof window === 'undefined') return;

    // Use intersection observer if available, otherwise trigger immediately
    if ('IntersectionObserver' in window) {
      const observer = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              entry.target.classList.add('animate-fade-in-up');
              observer.unobserve(entry.target);
            }
          });
        },
        { threshold: 0.1, rootMargin: '50px' }
      );

      // Observe all animation elements
      document.querySelectorAll('.animate-on-scroll').forEach((el) => {
        observer.observe(el);
      });

      // Cleanup function
      return () => observer.disconnect();
    } else {
      // Fallback: trigger all animations immediately
      document.querySelectorAll('.animate-on-scroll').forEach((el, index) => {
        setTimeout(() => {
          el.classList.add('animate-fade-in-up');
        }, index * 100);
      });
    }
  };

  const loadInitialEvents = async () => {
    try {
      setLoading(true);
      const initialLimit = getInitialLimit();

      const params: {
        limit: number;
        offset: number;
        category?: string;
        search?: string;
      } = {
        limit: initialLimit,
        offset: 0,
      };

      if (selectedCategory !== 'All') {
        params.category = selectedCategory;
      }

      if (activeSearchTerm.trim()) {
        params.search = activeSearchTerm.trim();
      }

      const response: PaginationResponse<Event> = await api.getEvents(params);
      setEvents(response.events || []);
      setHasMore(response.pagination.hasMore);
      setNextOffset(response.pagination.nextOffset);

      // Refresh categories in case new ones were added
      loadCategories();
    } catch (error) {
      console.error('Failed to load events:', error);
      // Use fallback mock data
      const mockEvents = [
        {
          _id: '1',
          title: 'Tech Innovation Summit 2024',
          description: 'Join industry leaders and innovators for a day of cutting-edge technology discussions, networking, and hands-on workshops. Discover the latest trends in AI, blockchain, and sustainable tech.',
          date: '2024-03-15',
          time: '09:00',
          location: 'San Francisco Convention Center',
          maxAttendees: 500,
          currentAttendees: 342,
          price: 299,
          image: 'https://images.pexels.com/photos/2608517/pexels-photo-2608517.jpeg?auto=compress&fit=crop&w=800&q=80',
          category: 'Technology',
          organizer: 'TechVision Inc.',
          tags: ['AI', 'Innovation', 'Networking', 'Workshop']
        },
        {
          _id: '2',
          title: 'Business Leadership Forum',
          description: 'Meet top business leaders and learn about the latest trends in entrepreneurship and management.',
          date: '2024-04-10',
          time: '10:00',
          location: 'New York Business Center',
          maxAttendees: 300,
          currentAttendees: 180,
          price: 199,
          image: 'https://images.pexels.com/photos/3183197/pexels-photo-3183197.jpeg?auto=compress&fit=crop&w=800&q=80',
          category: 'Business',
          organizer: 'BizLeaders',
          tags: ['Business', 'Leadership', 'Networking']
        }
      ];
      setEvents(mockEvents);
      setHasMore(true);
    } finally {
      setLoading(false);
    }
  };

  const loadMoreEvents = async () => {
    if (!hasMore || nextOffset === null || loadingMore) return;

    try {
      setLoadingMore(true);
      const loadMoreLimit = getLoadMoreLimit();

      const params: {
        limit: number;
        offset: number;
        category?: string;
        search?: string;
      } = {
        limit: loadMoreLimit,
        offset: nextOffset,
      };

      if (selectedCategory !== 'All') {
        params.category = selectedCategory;
      }

      if (activeSearchTerm.trim()) {
        params.search = activeSearchTerm.trim();
      }

      const response: PaginationResponse<Event> = await api.getEvents(params);
      const newEvents = response.events || [];

      setEvents(prevEvents => [...prevEvents, ...newEvents]);
      setHasMore(response.pagination.hasMore);
      setNextOffset(response.pagination.nextOffset);

      // Trigger animations for new events
      setTimeout(() => {
        const newEventCards = document.querySelectorAll('.event-card:not(.animate-fade-in-up)');
        newEventCards.forEach((card, index) => {
          setTimeout(() => {
            card.classList.add('animate-fade-in-up');
          }, index * 100);
        });
      }, 100);
    } catch (error) {
      console.error('Failed to load more events:', error);
    } finally {
      setLoadingMore(false);
    }
  };

  // Load categories from API
  const loadCategories = async () => {
    try {
      const response = await api.getCategories();
      if (response.success && response.categories) {
        setCategories(['All', ...response.categories]);
      }
    } catch (error) {
      console.error('Failed to load categories:', error);
      // Fallback to basic categories if API fails
      setCategories(['All', 'Technology', 'Business', 'Marketing', 'Design', 'Education']);
    }
  };

  const handleRegister = async (eventId: string) => {
    const event = events.find(e => e._id === eventId);
    if (!event) return;

    setSelectedEvent(event);

    // If user is logged in, auto-register them
    if (isAuthenticated && user) {
      setIsRegistering(true);
      setRegistrationMessage(null);

      try {
        const response = await api.createRegistration({
          eventId: event._id,
          attendeeName: user.name,
          attendeeEmail: user.email,
          attendeePhone: user.phone || 'Not provided',
          ticketType: 'Standard'
        });

        if (response.success) {
          // Update local events state to reflect the new registration
          setEvents(prevEvents =>
            prevEvents.map(e =>
              e._id === event._id
                ? { ...e, currentAttendees: e.currentAttendees + 1 }
                : e
            )
          );

          // Set registration data for confirmation display
          setRegistrationData({
            name: user.name,
            email: user.email,
            phone: user.phone || 'Not provided',
            eventTitle: event.title
          });

          setShowConfirmation(true);
          setShowRegisterModal(true);
        }
      } catch (error: any) {
        console.error('Registration error:', error);
        setRegistrationMessage({
          type: 'error',
          text: error.message || 'Registration failed. Please try again.'
        });
        setShowRegisterModal(true);
      } finally {
        setIsRegistering(false);
      }
    } else {
      // If user is not logged in, show the registration form
      setShowConfirmation(false);
      setShowRegisterModal(true);
    }
  };

  const handleRegistrationSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedEvent) return;

    setIsRegistering(true);
    setRegistrationMessage(null);

    try {
      const response = await api.createRegistration({
        eventId: selectedEvent._id,
        attendeeName: registrationForm.name,
        attendeeEmail: registrationForm.email,
        attendeePhone: registrationForm.phone,
        ticketType: 'Standard'
      });

      if (response.success) {
        // Update local events state to reflect the new registration
        setEvents(prevEvents =>
          prevEvents.map(event =>
            event._id === selectedEvent._id
              ? { ...event, currentAttendees: event.currentAttendees + 1 }
              : event
          )
        );

        setRegistrationMessage({
          type: 'success',
          text: 'Registration successful! You will receive a confirmation email shortly.'
        });

        // Reset form and close modal after a delay
        setTimeout(() => {
          setShowRegisterModal(false);
          setRegistrationForm({ name: '', email: '', phone: '' });
          setSelectedEvent(null);
          setRegistrationMessage(null);
        }, 2000);
      }
    } catch (error: any) {
      console.error('Registration error:', error);
      setRegistrationMessage({
        type: 'error',
        text: error.message || 'Registration failed. Please try again.'
      });
    } finally {
      setIsRegistering(false);
    }
  };

  // Search button handler
  const handleSearch = () => {
    setActiveSearchTerm(pendingSearchTerm);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading events...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="relative min-h-screen w-full overflow-x-hidden" style={{ backgroundImage: `url(${hpBG})`, backgroundSize: 'cover', backgroundPosition: 'center', backgroundRepeat: 'no-repeat' }}>
      {/* Enhanced Tagline & Search Section */}
      <div ref={heroRef} className="pt-20 pb-12 text-center animate-on-scroll relative z-10" style={{ backgroundImage: `url(${hpBG})`, backgroundSize: 'cover', backgroundPosition: 'center', backgroundRepeat: 'no-repeat' }}>
        <div className="max-w-4xl mx-auto px-4 relative z-10">
          <h1 className="text-5xl md:text-6xl font-extrabold text-white mb-6 leading-tight animate-fade-in">
            Explore Amazing Events
          </h1>
          <p className="text-xl md:text-2xl text-green-50 mb-8 max-w-2xl mx-auto animate-fade-in-delay">
            Be part of a growing community of professionals and learners, coming together through events that inspire, educate, and connect lives.
          </p>

          {/* Animated Event Images Grid */}
          <div className="relative z-10 mt-8 mb-8 w-full max-w-3xl mx-auto">
            {/* Mobile: Cross layout for 5 images */}
            <div className="grid grid-cols-3 grid-rows-3 gap-3 w-56 mx-auto md:hidden animate-fade-in-up">
              <div className="row-start-1 col-start-2">
                <img src="https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?auto=format&fit=crop&w=400&q=80" alt="Live Concert" className="w-16 h-16 rounded-xl shadow-lg border-2 border-white object-cover transform hover:scale-105 transition duration-300 animate-zoom-in" />
              </div>
              <div className="row-start-2 col-start-1">
                <img src="https://eventsbyliz.com.ph/wp-content/uploads/2019/12/The-first-Wedding-Event-at-Acacia-Hotel.-Congratulations-JOKO-amp.xx&oh=2a65ce0fde7916aa6d97a8e3e8d59fb6&oe=5EB3092D.jpeg" alt="Wedding" className="w-16 h-16 rounded-xl shadow-lg border-2 border-white object-cover transform hover:scale-105 transition duration-300 animate-zoom-in delay-100" />
              </div>
              <div className="row-start-2 col-start-2">
                <img src="https://hcil.umd.edu/wp-content/uploads/2015/08/seminar-conference.jpg" alt="Student, College & Campus Events" className="w-16 h-16 rounded-xl shadow-lg border-2 border-white object-cover transform hover:scale-105 transition duration-300 animate-zoom-in delay-200" />
              </div>
              <div className="row-start-2 col-start-3">
                <img src="https://www.liysf.org.uk/wp-content/uploads/2019/01/61st-LIYSF-2019-120.jpg" alt="Cultural & Social Events" className="w-16 h-16 rounded-xl shadow-lg border-2 border-white object-cover transform hover:scale-105 transition duration-300 animate-zoom-in delay-300" />
              </div>
              <div className="row-start-3 col-start-2">
                <img src="https://images.pexels.com/photos/3183197/pexels-photo-3183197.jpeg?auto=compress&fit=crop&w=300&q=80" alt="Business & Professional Events" className="w-16 h-16 rounded-xl shadow-lg border-2 border-white object-cover transform hover:scale-105 transition duration-300 animate-zoom-in delay-400" />
              </div>
            </div>
            {/* Desktop/Tablet: Straight row of 5 */}
            <div className="hidden md:grid grid-cols-5 gap-4 w-full animate-fade-in-up">
              <img src="https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?auto=format&fit=crop&w=400&q=80" alt="Live Concert" className="w-24 h-24 md:w-28 md:h-28 rounded-xl shadow-lg border-2 border-white object-cover transform hover:scale-105 transition duration-300 animate-zoom-in" />
              <img src="https://eventsbyliz.com.ph/wp-content/uploads/2019/12/The-first-Wedding-Event-at-Acacia-Hotel.-Congratulations-JOKO-amp.xx&oh=2a65ce0fde7916aa6d97a8e3e8d59fb6&oe=5EB3092D.jpeg" alt="Wedding" className="w-24 h-24 md:w-28 md:h-28 rounded-xl shadow-lg border-2 border-white object-cover transform hover:scale-105 transition duration-300 animate-zoom-in delay-100" />
              <img src="https://hcil.umd.edu/wp-content/uploads/2015/08/seminar-conference.jpg" alt="Student, College & Campus Events" className="w-24 h-24 md:w-28 md:h-28 rounded-xl shadow-lg border-2 border-white object-cover transform hover:scale-105 transition duration-300 animate-zoom-in delay-200" />
              <img src="https://www.liysf.org.uk/wp-content/uploads/2019/01/61st-LIYSF-2019-120.jpg" alt="Cultural & Social Events" className="w-24 h-24 md:w-28 md:h-28 rounded-xl shadow-lg border-2 border-white object-cover transform hover:scale-105 transition duration-300 animate-zoom-in delay-300" />
              <img src="https://images.pexels.com/photos/3183197/pexels-photo-3183197.jpeg?auto=compress&fit=crop&w=300&q=80" alt="Business & Professional Events" className="w-24 h-24 md:w-28 md:h-28 rounded-xl shadow-lg border-2 border-white object-cover transform hover:scale-105 transition duration-300 animate-zoom-in delay-400" />
            </div>
          </div>

          {/* Search and Filter */}
          <div className="rounded-xl border border-blue-200 mb-4 animate-on-scroll p-4 md:p-6 shadow-md md:shadow-xl backdrop-blur-md bg-white/90 md:bg-gradient-to-r md:from-blue-100 md:via-purple-100 md:to-pink-100/80">
            <div className="flex flex-col md:flex-row gap-3 md:gap-4 items-stretch md:items-center">
              <div className="flex-1 relative flex items-center">
                <Search className="absolute left-3 top-3 h-5 w-5 text-blue-500" />
                <input
                  type="text"
                  placeholder="Search events..."
                  value={pendingSearchTerm}
                  onChange={(e) => setPendingSearchTerm(e.target.value)}
                  onKeyDown={(e) => { if (e.key === 'Enter') { handleSearch(); } }}
                  className="w-full pl-10 pr-4 py-3 bg-white md:bg-gradient-to-r md:from-white md:via-blue-50 md:to-purple-50 border-2 border-blue-300 rounded-lg text-gray-900 placeholder-blue-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent shadow-sm md:shadow-md"
                />
                <button
                  onClick={handleSearch}
                  className="hidden md:inline-flex ml-3 px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white font-semibold rounded-lg shadow-lg hover:scale-105 hover:from-purple-600 hover:to-blue-600 transition-all duration-300"
                  style={{ position: 'relative', zIndex: 1 }}
                >
                  Search
                </button>
              </div>
              <div className="relative w-full md:w-auto">
                <Filter className="absolute left-3 top-3 h-5 w-5 text-blue-500" />
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="w-full md:w-auto pl-10 pr-8 py-3 bg-white md:bg-gradient-to-r md:from-white md:via-blue-50 md:to-purple-50 border-2 border-blue-300 rounded-lg text-gray-900 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none min-w-[150px] shadow-sm md:shadow-md"
                >
                  {categories.map(category => (
                    <option key={category} value={category} className="bg-white">
                      {category}
                    </option>
                  ))}
                </select>
              </div>
              {/* Mobile search button */}
              <button
                onClick={handleSearch}
                className="md:hidden w-full px-5 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white font-semibold rounded-lg shadow-md"
              >
                Search
              </button>
            </div>
          </div>

          {/* About Paragraph: Below search bar */}
          <div className="flex justify-center mt-4 mb-4 animate-on-scroll">
            <p className="max-w-2xl w-full text-center text-lg md:text-xl text-green-50 font-medium mx-auto">
              Eventinity is your one-stop platform to discover, search, and register for amazing events. Join our community and never miss out on the action!
            </p>
          </div>
        </div>
      </div>

      {/* Event Categories Section */}
      <section className="max-w-7xl mx-auto px-4 mt-12 mb-12">
        <h2 className="text-2xl md:text-3xl font-bold text-white mb-8 text-center">Explore Event Categories</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {/* Learning & Innovation */}
          <div className="rounded-2xl bg-blue-200 text-gray-900 shadow-xl p-6 flex flex-col transition-all duration-300 ease-out hover:shadow-2xl hover:scale-105 hover:-translate-y-2 hover:bg-blue-300 cursor-pointer group">
            <h3 className="text-xl font-bold mb-2 group-hover:text-blue-900 transition-colors duration-300">Learning & Innovation <span className='text-blue-600 group-hover:text-blue-800 transition-colors duration-300'>(Workshops, Tech, Webinars, Hackathons)</span></h3>
            <p className="mb-3 text-blue-800 group-hover:text-blue-900 transition-colors duration-300">Workshops, tech conferences, webinars, and hackathons to boost your skills and spark innovation.</p>
            <ul className="list-disc list-inside text-blue-700 group-hover:text-blue-800 text-sm space-y-1 pl-2 transition-colors duration-300">
              <li className="transform group-hover:translate-x-1 transition-transform duration-300">Python Bootcamp</li>
              <li className="transform group-hover:translate-x-1 transition-transform duration-300 delay-75">AI & ML Summit</li>
              <li className="transform group-hover:translate-x-1 transition-transform duration-300 delay-150">24hr Coding Challenge</li>
            </ul>
          </div>
          {/* Business & Professional Events */}
          <div className="rounded-2xl bg-green-200 text-gray-900 shadow-xl p-6 flex flex-col transition-all duration-300 ease-out hover:shadow-2xl hover:scale-105 hover:-translate-y-2 hover:bg-green-300 cursor-pointer group">
            <h3 className="text-xl font-bold mb-2 group-hover:text-green-900 transition-colors duration-300">Business & Professional Events <span className='text-green-600 group-hover:text-green-800 transition-colors duration-300'>(Business, Startup, Networking)</span></h3>
            <p className="mb-3 text-green-800 group-hover:text-green-900 transition-colors duration-300">Connect, network, and grow with top business minds and leaders.</p>
            <ul className="list-disc list-inside text-green-700 group-hover:text-green-800 text-sm space-y-1 pl-2 transition-colors duration-300">
              <li className="transform group-hover:translate-x-1 transition-transform duration-300">Entrepreneurship Summit</li>
              <li className="transform group-hover:translate-x-1 transition-transform duration-300 delay-75">Investor Meet</li>
              <li className="transform group-hover:translate-x-1 transition-transform duration-300 delay-150">Leadership Workshop</li>
            </ul>
          </div>
          {/* Cultural Festivals (Cultural) */}
          <div className="rounded-2xl bg-yellow-200 text-gray-900 shadow-xl p-6 flex flex-col transition-all duration-300 ease-out hover:shadow-2xl hover:scale-105 hover:-translate-y-2 hover:bg-yellow-300 cursor-pointer group">
            <h3 className="text-xl font-bold mb-2 group-hover:text-yellow-900 transition-colors duration-300">Cultural Festivals <span className='text-yellow-600 group-hover:text-yellow-800 transition-colors duration-300'>(Cultural)</span></h3>
            <p className="mb-3 text-yellow-800 group-hover:text-yellow-900 transition-colors duration-300">Celebrate diversity and traditions with vibrant festivals.</p>
            <ul className="list-disc list-inside text-yellow-700 group-hover:text-yellow-800 text-sm space-y-1 pl-2 transition-colors duration-300">
              <li className="transform group-hover:translate-x-1 transition-transform duration-300">Spring Music Fest</li>
              <li className="transform group-hover:translate-x-1 transition-transform duration-300 delay-75">Food & Art Carnival</li>
              <li className="transform group-hover:translate-x-1 transition-transform duration-300 delay-150">International Dance Gala</li>
            </ul>
          </div>
          {/* Entertainment Events */}
          <div className="rounded-2xl bg-pink-200 text-gray-900 shadow-xl p-6 flex flex-col transition-all duration-300 ease-out hover:shadow-2xl hover:scale-105 hover:-translate-y-2 hover:bg-pink-300 cursor-pointer group">
            <h3 className="text-xl font-bold mb-2 group-hover:text-pink-900 transition-colors duration-300">Entertainment Events <span className='text-pink-600 group-hover:text-pink-800 transition-colors duration-300'>(Concerts, Stand-up, Movies)</span></h3>
            <p className="mb-3 text-pink-800 group-hover:text-pink-900 transition-colors duration-300">Enjoy concerts, stand-up comedy, movie nights, and more fun-filled events.</p>
            <ul className="list-disc list-inside text-pink-700 group-hover:text-pink-800 text-sm space-y-1 pl-2 transition-colors duration-300">
              <li className="transform group-hover:translate-x-1 transition-transform duration-300">Live Concert</li>
              <li className="transform group-hover:translate-x-1 transition-transform duration-300 delay-75">Stand-up Night</li>
              <li className="transform group-hover:translate-x-1 transition-transform duration-300 delay-150">Open Air Movie</li>
            </ul>
          </div>
          {/* Sports Events */}
          <div className="rounded-2xl bg-indigo-200 text-gray-900 shadow-xl p-6 flex flex-col transition-all duration-300 ease-out hover:shadow-2xl hover:scale-105 hover:-translate-y-2 hover:bg-indigo-300 cursor-pointer group">
            <h3 className="text-xl font-bold mb-2 group-hover:text-indigo-900 transition-colors duration-300">Sports Events <span className='text-indigo-600 group-hover:text-indigo-800 transition-colors duration-300'>(Tournaments, Matches)</span></h3>
            <p className="mb-3 text-indigo-800 group-hover:text-indigo-900 transition-colors duration-300">Participate in or watch exciting sports tournaments and matches.</p>
            <ul className="list-disc list-inside text-indigo-700 group-hover:text-indigo-800 text-sm space-y-1 pl-2 transition-colors duration-300">
              <li className="transform group-hover:translate-x-1 transition-transform duration-300">Intercollege Sports Meet</li>
              <li className="transform group-hover:translate-x-1 transition-transform duration-300 delay-75">Football Tournament</li>
              <li className="transform group-hover:translate-x-1 transition-transform duration-300 delay-150">Cricket League</li>
            </ul>
          </div>
          {/* Social & Community Events */}
          <div className="rounded-2xl bg-purple-200 text-gray-900 shadow-xl p-6 flex flex-col transition-all duration-300 ease-out hover:shadow-2xl hover:scale-105 hover:-translate-y-2 hover:bg-purple-300 cursor-pointer group">
            <h3 className="text-xl font-bold mb-2 group-hover:text-purple-900 transition-colors duration-300">Social & Community Events <span className='text-purple-600 group-hover:text-purple-800 transition-colors duration-300'>(Charity, Meetups)</span></h3>
            <p className="mb-3 text-purple-800 group-hover:text-purple-900 transition-colors duration-300">Join hands for a cause or connect with your community through social events.</p>
            <ul className="list-disc list-inside text-purple-700 group-hover:text-purple-800 text-sm space-y-1 pl-2 transition-colors duration-300">
              <li className="transform group-hover:translate-x-1 transition-transform duration-300">Charity Run</li>
              <li className="transform group-hover:translate-x-1 transition-transform duration-300 delay-75">Community Meetup</li>
              <li className="transform group-hover:translate-x-1 transition-transform duration-300 delay-150">Blood Donation Camp</li>
            </ul>
          </div>
        </div>
      </section>

      {/* Featured Event */}
      {featuredEvent && (
        <div className="max-w-7xl mx-auto px-4 mb-12 animate-on-scroll" style={{ backgroundImage: `url(${hpBG})`, backgroundSize: 'cover', backgroundPosition: 'center', backgroundRepeat: 'no-repeat' }}>
          <h2 className="text-3xl font-bold text-white drop-shadow-lg mb-6">Featured Event</h2>
          <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl overflow-hidden shadow-xl transform hover:scale-[1.02] transition-all duration-300">
            <div className="flex flex-col lg:flex-row">
              <div className="w-full lg:w-2/5 h-64 lg:h-auto bg-cover bg-center" style={{ backgroundImage: `url(${featuredEvent.image})` }}>
                <div className="w-full h-full bg-gradient-to-t from-black/20 to-transparent"></div>
              </div>
              <div className="flex-1 p-6 lg:p-8 text-white">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="text-2xl lg:text-3xl font-bold mb-2">{featuredEvent.title}</h3>
                    <span className="inline-block bg-white/20 backdrop-blur-sm text-white px-3 py-1 rounded-full text-sm font-medium mb-2">
                      {featuredEvent.category}
                    </span>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold text-white">${featuredEvent.price}</div>
                  </div>
                </div>

                <p className="text-blue-100 mb-6 leading-relaxed">{featuredEvent.description}</p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
                  <div className="flex items-center text-blue-100">
                    <Calendar className="h-5 w-5 mr-3" />
                    <span>{featuredEvent.date} at {featuredEvent.time}</span>
                  </div>
                  <div className="flex items-center text-blue-100">
                    <MapPin className="h-5 w-5 mr-3" />
                    <span>{featuredEvent.location}</span>
                  </div>
                  <div className="flex items-center text-blue-100">
                    <Users className="h-5 w-5 mr-3" />
                    <span>{featuredEvent.currentAttendees} / {featuredEvent.maxAttendees} attendees</span>
                  </div>
                </div>

                {/* Progress bar */}
                <div className="mb-6">
                  <div className="flex justify-between text-sm text-blue-100 mb-2">
                    <span>Registration Progress</span>
                    <span>{Math.round((featuredEvent.currentAttendees / featuredEvent.maxAttendees) * 100)}%</span>
                  </div>
                  <div className="w-full bg-white/20 rounded-full h-2">
                    <div
                      className="bg-white h-2 rounded-full transition-all duration-300"
                      style={{ width: `${(featuredEvent.currentAttendees / featuredEvent.maxAttendees) * 100}%` }}
                    ></div>
                  </div>
                </div>

                <button
                  onClick={() => handleRegister(featuredEvent._id)}
                  disabled={featuredEvent.currentAttendees >= featuredEvent.maxAttendees}
                  className={`w-full sm:w-auto px-8 py-3 rounded-lg font-semibold transition-colors ${featuredEvent.currentAttendees >= featuredEvent.maxAttendees
                    ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                    : 'bg-white text-blue-600 hover:bg-gray-100'
                    }`}
                >
                  {featuredEvent.currentAttendees >= featuredEvent.maxAttendees ? 'Sold Out' : 'Register Now'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Events Grid */}
      <div ref={eventsRef} className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8" style={{ backgroundImage: `url(${hpBG})`, backgroundSize: 'cover', backgroundPosition: 'center', backgroundRepeat: 'no-repeat' }}>
        <h2 className="text-3xl font-bold text-white drop-shadow-lg mb-8 text-center animate-on-scroll">Upcoming Events</h2>
        {events.length === 0 ? (
          <div className="text-center py-12 bg-white/10 backdrop-blur-md rounded-2xl mx-4 border border-white/20">
            <div className="mb-4">
              <svg className="mx-auto h-16 w-16 text-white/60" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0116 0z" />
              </svg>
            </div>
            <h3 className="text-xl font-semibold text-white mb-2">No Events Found</h3>
            <p className="text-white/80 text-lg">No events match your search criteria.</p>
            <p className="text-white/60 text-sm mt-2">Try adjusting your search terms or category filter.</p>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
              {events.map((event) => (
                <div key={event._id} className="event-card animate-on-scroll">
                  <EventCard event={event} onRegister={() => handleRegister(event._id)} showRegisterButton={true} />
                </div>
              ))}
            </div>

            {/* Load More Button */}
            {hasMore && (
              <div className="text-center animate-on-scroll">
                <button
                  onClick={loadMoreEvents}
                  disabled={loadingMore}
                  className="bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white px-8 py-3 rounded-lg font-semibold transition-all duration-200 transform hover:scale-105 disabled:scale-100 disabled:cursor-not-allowed flex items-center gap-2 mx-auto"
                >
                  {loadingMore ? (
                    <>
                      <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                      Loading...
                    </>
                  ) : (
                    <>
                      <ChevronDown className="h-5 w-5" />
                      Load More Events
                    </>
                  )}
                </button>
              </div>
            )}
          </>
        )}
      </div>

      {/* Registration Modal */}
      {showRegisterModal && selectedEvent && (
        <Modal
          isOpen={showRegisterModal}
          onClose={() => {
            setShowRegisterModal(false);
            setShowConfirmation(false);
            setRegistrationData(null);
            setRegistrationMessage(null);
          }}
          title=""
          size="md"
        >
          <div className="bg-white/90 backdrop-blur-md rounded-2xl shadow-2xl overflow-hidden">
            {/* Title Section */}
            <div className="bg-gradient-to-r from-blue-700 via-blue-600 to-blue-500 px-6 py-4">
              <h3 className="text-xl font-bold text-white text-center">
                {showConfirmation ? 'Registration Confirmed!' : `Register for ${selectedEvent.title}`}
              </h3>
            </div>

            {/* Content Section */}
            <div className="p-6 space-y-6">
              {showConfirmation && registrationData ? (
                /* Confirmation View for Logged-in Users */
                <div className="space-y-6">
                  {/* Success Message */}
                  <div className="animate-scaleUp p-4 rounded-lg border bg-green-50 border-green-200 text-green-800">
                    <div className="flex items-center">
                      <div className="flex-shrink-0 mr-3">
                        <svg className="h-8 w-8 text-green-600" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                        </svg>
                      </div>
                      <div>
                        <h4 className="text-lg font-semibold text-green-800">Successfully Registered!</h4>
                        <p className="text-sm text-green-700">You will receive a confirmation email shortly.</p>
                      </div>
                    </div>
                  </div>

                  {/* Registration Details */}
                  <div className="bg-blue-50/80 rounded-lg p-4 border border-blue-100">
                    <h4 className="text-blue-800 font-semibold mb-3">Registration Details</h4>
                    <div className="space-y-2 text-blue-700 text-sm">
                      <div className="flex justify-between">
                        <span className="font-medium">Name:</span>
                        <span>{registrationData.name}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="font-medium">Email:</span>
                        <span>{registrationData.email}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="font-medium">Phone:</span>
                        <span>{registrationData.phone}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="font-medium">Event:</span>
                        <span>{registrationData.eventTitle}</span>
                      </div>
                    </div>
                  </div>

                  {/* Event Details */}
                  <div className="bg-gray-50/80 rounded-lg p-4 border border-gray-200">
                    <h4 className="text-gray-800 font-semibold mb-3">Event Information</h4>
                    <div className="space-y-2 text-gray-700 text-sm">
                      <div className="flex items-center">
                        <Calendar className="h-4 w-4 mr-2" />
                        {selectedEvent.date} at {selectedEvent.time}
                      </div>
                      <div className="flex items-center">
                        <MapPin className="h-4 w-4 mr-2" />
                        {selectedEvent.location}
                      </div>
                      <div className="flex items-center">
                        <span className="font-semibold">Price: ${selectedEvent.price}</span>
                      </div>
                    </div>
                  </div>

                  {/* Close Button */}
                  <div className="pt-4">
                    <button
                      onClick={() => {
                        setShowRegisterModal(false);
                        setShowConfirmation(false);
                        setRegistrationData(null);
                      }}
                      className="w-full px-6 py-3 bg-blue-800 text-white rounded-lg font-semibold hover:bg-blue-900 focus:outline-none focus:ring-2 focus:ring-blue-700 focus:ring-offset-2 transition-all duration-200 transform hover:scale-105 active:scale-95"
                    >
                      Close
                    </button>
                  </div>
                </div>
              ) : (
                /* Registration Form for Non-logged-in Users */
                <form onSubmit={handleRegistrationSubmit} className="space-y-6">
                  <div className="animate-slideDown" style={{ animationDelay: '0.1s', animationFillMode: 'both' }}>
                    <label className="block text-gray-700 text-sm font-medium mb-2">Full Name</label>
                    <input
                      type="text"
                      required
                      value={registrationForm.name}
                      onChange={(e) => setRegistrationForm(prev => ({ ...prev, name: e.target.value }))}
                      className="w-full px-4 py-3 bg-white border border-gray-200 rounded-lg text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 shadow-sm"
                      placeholder="Enter your full name"
                    />
                  </div>
                  <div className="animate-slideDown" style={{ animationDelay: '0.2s', animationFillMode: 'both' }}>
                    <label className="block text-gray-700 text-sm font-medium mb-2">Email</label>
                    <input
                      type="email"
                      required
                      value={registrationForm.email}
                      onChange={(e) => setRegistrationForm(prev => ({ ...prev, email: e.target.value }))}
                      className="w-full px-4 py-3 bg-white border border-gray-200 rounded-lg text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 shadow-sm"
                      placeholder="Enter your email address"
                    />
                  </div>
                  <div className="animate-slideDown" style={{ animationDelay: '0.3s', animationFillMode: 'both' }}>
                    <label className="block text-gray-700 text-sm font-medium mb-2">Phone Number</label>
                    <input
                      type="tel"
                      required
                      value={registrationForm.phone}
                      onChange={(e) => setRegistrationForm(prev => ({ ...prev, phone: e.target.value }))}
                      className="w-full px-4 py-3 bg-white border border-gray-200 rounded-lg text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 shadow-sm"
                      placeholder="Enter your phone number"
                    />
                  </div>

                  {/* Event Details */}
                  <div className="animate-slideDown bg-blue-50/80 rounded-lg p-4 border border-blue-100" style={{ animationDelay: '0.4s', animationFillMode: 'both' }}>
                    <h4 className="text-blue-800 font-semibold mb-2">Event Details</h4>
                    <div className="space-y-1 text-blue-700 text-sm">
                      <div className="flex items-center">
                        <Calendar className="h-4 w-4 mr-2" />
                        {selectedEvent.date} at {selectedEvent.time}
                      </div>
                      <div className="flex items-center">
                        <MapPin className="h-4 w-4 mr-2" />
                        {selectedEvent.location}
                      </div>
                      <div className="flex items-center">
                        <span className="font-semibold">Price: ${selectedEvent.price}</span>
                      </div>
                    </div>
                  </div>

                  {/* Registration Message */}
                  {registrationMessage && (
                    <div className={`animate-scaleUp p-4 rounded-lg border ${registrationMessage.type === 'success'
                      ? 'bg-green-50 border-green-200 text-green-800'
                      : 'bg-red-50 border-red-200 text-red-800'
                      }`}>
                      <div className="flex items-center">
                        {registrationMessage.type === 'success' ? (
                          <div className="flex-shrink-0 mr-3">
                            <svg className="h-5 w-5 text-green-600" fill="currentColor" viewBox="0 0 20 20">
                              <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                            </svg>
                          </div>
                        ) : (
                          <div className="flex-shrink-0 mr-3">
                            <svg className="h-5 w-5 text-red-600 animate-bounce" fill="currentColor" viewBox="0 0 20 20">
                              <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                            </svg>
                          </div>
                        )}
                        <span className="text-sm font-medium">{registrationMessage.text}</span>
                      </div>
                    </div>
                  )}

                  {/* Action Buttons */}
                  <div className="flex gap-4 pt-4">
                    <button
                      type="button"
                      onClick={() => setShowRegisterModal(false)}
                      disabled={isRegistering}
                      className="flex-1 px-6 py-3 bg-gray-100 text-gray-700 rounded-lg font-semibold hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={isRegistering}
                      className="flex-1 px-6 py-3 bg-blue-800 text-white rounded-lg font-semibold hover:bg-blue-900 focus:outline-none focus:ring-2 focus:ring-blue-700 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 transform hover:scale-105 active:scale-95"
                    >
                      {isRegistering ? (
                        <>
                          <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white inline-block mr-2"></div>
                          Registering...
                        </>
                      ) : (
                        'Register Now'
                      )}
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        </Modal>
      )}
      <ChatbotWidget />
    </div>
  );
};

export default HomePage;